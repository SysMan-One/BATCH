#ifndef	__AVPROTO$DEF__
#define	__AVPROTO$DEF__	1

#ifdef _WIN32
	#pragma once
	#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#endif


/*
**++
**
**  FACILITY:  AVProto - Attribute/Value Pair (AKA TLV) based protocol
**
**  ABSTRACT: Carrying data encapsulated in to the AVP microcontainers
**
**  DESCRIPTION: Data structures and constants of the AVProto core and API routines.
**	A PDU is a Header (magic[8], len, csr, seq - all NBO) followed by a payload of
**	TLVs; a TLV is a tag (type:4 | id:12 bits), a 16-bit length and the value.
**
**  AUTHORS: StarLet Squad and Ruslan R. Laishev (AKA: BadAss SysMan)
**
**  CREATION DATE:  20-JUL-2018
**
**  MODIFICATION HISTORY:
**
**	15-FEB-2019	RRL	Removed bitfields.
**
**	22-FEB-2019	RRL	Added closing for "#ifdef __cplusplus", some code reorganizing.
**
**	29-JUL-2019	RRL	__tlv$dump() declared; improved error handling in __tlv$hget().
**
**	01-AUG-2026	CLD	__tlv$hget() compared the magic over its full width, reading past a short signature;
**				it now compares a zero-padded copy, as __tlv$hset() stores it.
**
**	22-OCT-2026	RRL	Windows: be16/be32/be64toh(), htobe16/32/64() through _byteswap_*() (MSVC, MinGW-w64).
**
**	31-OCT-2026	CLD	StarLet 1.7.0: GCC diagnostic pragmas no longer leak to includers; __tlv$put() size is
**				<unsigned>; __tlv$hset() rejects a signature over 8 octets; __tlv$hget() leaves *a_u_csr on error.
**
**--
*/

#include	<string.h>
#ifdef	_WIN32
#include	<stdlib.h>		/* _byteswap_ushort/_ulong/_uint64() - MSVC and MinGW-w64 alike; Windows is little-endian only */
#ifndef	be32toh
#define	be32toh(x)	_byteswap_ulong(x)
#endif
#define	htobe32(x)	_byteswap_ulong(x)
#define	be16toh(x)	_byteswap_ushort(x)
#define	be64toh(x)	_byteswap_uint64(x)
#define	htobe64(x)	_byteswap_uint64(x)
#define	htobe16(x)	_byteswap_ushort(x)
#else
#include	<endian.h>
#endif


#ifdef __cplusplus
extern "C" {
#endif



/*
 * AVP/TLV - type of block types to help transparent conversion of the well-know datas
 * is carried in NBO or to help LE/Be conversion
 */
enum	{
	TAG$K_BBLOCK = 0,	/* A default type - octets block	*/
	TAG$K_WORD = 3,		/* 16-bits word, NBO			*/
	TAG$K_LONGWORD,		/* 32-bits word, NBO			*/
	TAG$K_QWORD,		/* 64-bits word, NBO			*/
	TAG$K_UUID = 8,		/* UUID					*/


	TAG$K_MAX		/* EOL marker, must be last!		*/
};


#pragma	pack (push, 1)

#define	TAG$M_TYPE	0xf000
#define	TAG$M_ID	(~(TAG$M_TYPE))

typedef struct ____tlv$tlv__ {

	unsigned short	w_tag;	/* Tag's type and id			*/
	unsigned short	w_len;	/* Actual data length in the b_val[]	*/

	union	{		/* Placeholder for data block		*/
		unsigned char	b_val[0];
		unsigned short	w_val[0];
		unsigned	u_val[0];
	unsigned long long	q_val[0];
	};
} AVPROTO_TLV;

typedef struct ____tlv$hdr__ {
	unsigned char	magic[8];
	unsigned	u_len;		/* A length of payload follows header	*/
	unsigned	u_csr;		/* Command/Status Register		*/

	unsigned	u_seq;		/* A PDU sequence number is supposed to help
					  parallel and asyncronus processing	*/

} AVPROTO_HDR;

typedef struct ____tlv$pdu__ {
	AVPROTO_HDR	r_hdr;		/* Fixed length header			*/
	AVPROTO_TLV	r_tlv[0];	/* Placeholder for variable part of PDU	*/
} AVPROTO_PDU;

#pragma	pack (pop)

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**	Pack a tag type and identifier into a TLV tag field, [ type : 4 | id : 12 ], in NBO.
**
**  FORMAL PARAMETERS:
**
**	a_v_type	Tag type; one of the TAG$K_* constants (four bits)
**	a_v_tag	Application tag identifier (twelve bits)
**
**  IMPLICIT INPUTS/OUTPUTS:
**	NONE.
**
**  RETURN VALUE:
**	The packed w_tag field, in network byte order.
**--
*/
inline	static unsigned short __tlv$encode_tag
		(
	unsigned short	a_v_type,
	unsigned short	a_v_tag
		)
{
	/* Pack layout: w_tag = [ type : 4 bits | id : 12 bits ], returned in NBO */
	return	htobe16 ( ( (a_v_type << 12) | a_v_tag ));
}

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**	Extract the tag type (high 4 bits) and identifier (low 12 bits) from a TLV tag field.
**
**  FORMAL PARAMETERS:
**
**	a_w_tag	The w_tag field, in network byte order
**	a_v_type	Receives the tag type
**	a_v_tag	Receives the tag identifier
**
**  IMPLICIT INPUTS/OUTPUTS:
**	NONE.
**
**  RETURN VALUE:
**	The tag field in host byte order.
**--
*/
inline static unsigned short	__tlv$decode_tag
		(
	unsigned short	a_w_tag,
	unsigned short	*a_v_type,
	unsigned short	*a_v_tag
		)
{
unsigned short	l_tag = 0;

	l_tag = be16toh(a_w_tag);

	/* Unpack: high 4 bits -> type, low 12 bits -> id (see TAG$M_TYPE/TAG$M_ID) */
	*a_v_type = l_tag >> 12;
	*a_v_tag = l_tag & TAG$M_ID;

	return	l_tag;
}


int	__tlv$put    (void *a_pdu, unsigned a_pdusz, unsigned a_v_tag, unsigned a_v_type, void *a_val, unsigned a_valsz);
int	__tlv$get    (void *a_pdu, unsigned a_pdusz, int *a_context, unsigned a_v_tag, unsigned *a_v_type, void *a_val, unsigned *a_valsz);
int	__tlv$lookup (void *a_pdu, unsigned a_pdusz, int *a_context, unsigned a_v_tag, unsigned *a_v_type, void **a_val, unsigned *a_valsz);
void	__tlv$dump   (void *a_pdu, unsigned a_pdusz);


/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**	Initialise the PDU header (payload length 0, fields in NBO); call it before the first __tlv$put().
**
**  FORMAL PARAMETERS:
**
**	a_pdup	Address of the PDU buffer
**	a_sig	Protocol signature, a NUL-terminated string of 1 to 8 octets, zero-padded into the
**		eight-octet magic field; a longer one (or NULL) is an error and the PDU is not touched
**	a_u_csr	Command/status register value
**	a_u_seq	PDU sequence number
**
**  IMPLICIT INPUTS/OUTPUTS:
**	NONE.
**
**  RETURN VALUE:
**	STS$K_SUCCESS; STS$K_ERROR if the signature is NULL or longer than eight octets.
**--
*/
inline static int	__tlv$hset	(
		void		*a_pdup,
	const unsigned char	*a_sig,
		unsigned	a_u_csr,
		unsigned	a_u_seq
			)
{
size_t		l_siglen;
AVPROTO_PDU	*l_pdu = (AVPROTO_PDU *) a_pdup;

	if ( !a_sig )
		return	STS$K_ERROR;

	/* A signature longer than the magic field is rejected, exactly as __tlv$hget() does - never cut silently */
	if ( (l_siglen = strnlen((const char *) a_sig, sizeof(l_pdu->r_hdr.magic) + 1)) > sizeof(l_pdu->r_hdr.magic) )
		return	STS$K_ERROR;

	memset(&l_pdu->r_hdr, 0, sizeof(AVPROTO_HDR));
	memcpy(l_pdu->r_hdr.magic, a_sig, l_siglen);		/* rest stays zero-padded by memset above */

	l_pdu->r_hdr.u_csr = htobe32(a_u_csr);
	l_pdu->r_hdr.u_seq = htobe32(a_u_seq);

	return	STS$K_SUCCESS;
}


/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**	Validate a PDU signature and extract the header fields (converted to host byte order).
**
**  FORMAL PARAMETERS:
**
**	a_pdup	Address of the received PDU
**	a_sig	Expected signature (1 to 8 octets, NUL-terminated); a mismatch or a longer one is an error
**	a_u_len	Receives the payload length declared in the header
**	a_u_csr	Receives the command/status register
**	a_u_seq	Receives the sequence number
**
**  IMPLICIT INPUTS/OUTPUTS:
**	NONE.
**
**  RETURN VALUE:
**	STS$K_SUCCESS if the signature matched; STS$K_ERROR otherwise. On error NONE of the
**	output parameters (a_u_len, a_u_csr, a_u_seq) is written.
**--
*/
inline static int	__tlv$hget	(
		void		*a_pdup,
	const unsigned char	*a_sig,
		unsigned	*a_u_len,
		unsigned	*a_u_csr,
		unsigned	*a_u_seq
			)
{
size_t		l_len;
AVPROTO_PDU	*l_pdu = (AVPROTO_PDU *) a_pdup;
unsigned char	l_sigbuf[sizeof(l_pdu->r_hdr.magic)];	/* zero-padded copy of a_sig	*/

	if ( !a_sig )
		return	STS$K_ERROR;

	if ( (l_len = strnlen((const char *) a_sig, sizeof(l_pdu->r_hdr.magic) + 1)) > sizeof(l_pdu->r_hdr.magic) )
		return	STS$K_ERROR;

	/* Compare against a zero-padded copy of the signature so that a caller may
	** pass a string shorter than the magic field without reading past its end;
	** __tlv$hset() zero-pads the stored magic in the same way.
	*/
	memset(l_sigbuf, 0, sizeof(l_sigbuf));
	memcpy(l_sigbuf, a_sig, l_len);

	if ( memcmp(l_pdu->r_hdr.magic, l_sigbuf, sizeof(l_sigbuf)) )
		return	STS$K_ERROR;

	*a_u_len = be32toh(l_pdu->r_hdr.u_len);
	*a_u_csr = be32toh(l_pdu->r_hdr.u_csr);
	*a_u_seq = be32toh(l_pdu->r_hdr.u_seq);

	return	STS$K_SUCCESS;
}


#ifdef __cplusplus
	}
#endif

#endif	/* #ifndef	__AVPROTO$DEF__	*/
